<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('builderprofile', function (Blueprint $table) {
            $table->id();
            $table->string('buildername');
            $table->string('age');
            $table->string('Phone_no');
            $table->longtext('information');
            $table->string('rates');
            $table->string('username');
            $table->string('pass');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('builderprofile');
    }
};
