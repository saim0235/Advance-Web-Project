<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class builder extends Model
{
    use HasFactory;
    protected $table="builderprofile";
    protected $fillable =['buildername','age','Phone_no','information','rates','username','pass'];
}
