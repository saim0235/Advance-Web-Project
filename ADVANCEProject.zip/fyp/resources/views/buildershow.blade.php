<!DOCTYPE html>
<html>
    <head> 
        <title> Admin Panel</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    
<body>
<h1 class="text-center">builder list</h1> <br>
<div class="container">
	<table class="table table-bordered shadow text-center table-striped">
		<tr>
			<th>id</th>
			<th>Full Name</th>
			<th>Age </th>
            <th>Phone Number</th>
			<th>Expert </th>
            <th>Rates</th>
			<th>Username </th>
            <th>Password</th>
		</tr>
		@foreach($post as $post)
		<tr>
			<td>{{$post->id}}</td>
			<td>{{$post->buildername}}</td>
			<td>{{$post->age}}</td>
            <td>{{$post->Phone_no}}</td>
			<td>{{$post->information}}</td>
            <td>{{$post->rates}}</td>
			<td>{{$post->username}}</td>
            <td>{{$post->pass}}</td>
			<td><a href="/delete1/{{$post->id}}" class="btn btn-danger">delete</a></td>
			<td><a href="/edit1/{{$post->id}}" class="btn btn-success">edit</a></td>
		</tr>
		@endforeach
	</table>


	<!-- <form method="GET" action="/companyfirstpage">
<input type="submit" name="insert" Value="Check Any order"class="btn btn-success">
</form> -->
</br>
	
</div>


    
</body>
</html> 
