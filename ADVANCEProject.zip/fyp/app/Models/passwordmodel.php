<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class passwordmodel extends Model
{
    use HasFactory;
    protected $table="passwords";
    protected $fillable =['companyusername','companypassword','adminusername','adminpassword'];
}
