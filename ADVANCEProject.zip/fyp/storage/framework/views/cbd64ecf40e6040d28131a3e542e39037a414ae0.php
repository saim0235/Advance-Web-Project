<!DOCTYPE html>
<html>
    <head> 
        <title> Company</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    
<body>

    <h1 class="text-center">Admin Panel</h1> <br>
    <div class="container"> 

    <table class="table table-bordered shadow text-center table-striped">


    <tr>
			<th>
            <form action="/show">
                <input type="submit" name="submit" value="Open Company Profile" class="btn btn-success">
            </form>

            </th>
			<th>
            <form action="/Home">
                <input type="submit" name="submit" value="Check Home Page" class="btn btn-success">
            </form>

            </th>


            <th>
            <form action="/10">
                <input type="submit" name="submit" value="Add Builder" class="btn btn-success">
            </form>

            </th>
		</tr>


   </table>
    </div>

</body>
</html> 
<?php /**PATH C:\Xampp 8.1\htdocs\fyp\resources\views/adminpanel.blade.php ENDPATH**/ ?>