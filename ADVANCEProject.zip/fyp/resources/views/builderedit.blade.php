<!DOCTYPE html>
<html>
    <head> 
        <title> Builder</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    
<body>

    <h1 class="text-center">Update Builder</h1> <br>
    <div class="container">

    <form method="GET" action="/update1/{{$post->id}}">


        <div class="mb-3">
            <label> <b>Full Name</b></label>
            <input type="text" name="buildername" class="form-control" value={{$post->buildername}}>
        </div>

        <div class="mb-3">
            <label> <b>Age</b></label>
            <input type="text" name="age" class="form-control" value={{$post->age}}>
        </div>

        <div class="mb-3">
            <label> <b>Phone Number</b></label>
            <input type="text" name="Phone_no" class="form-control" value={{$post->Phone_no}}>
        </div>

        <div class="mb-50">
            <label > <b>Expert in Work</b></label>
            <input type="text" name="information" class="form-control" value={{$post->information}}>
        </div>

        <div class="mb-3">
            <label> <b>Builder Rate</b></label>
            <input type="text" name="rates" class="form-control" value={{$post->rates}}>
        </div>

        <div class="mb-3">
            <label> <b>User Name</b></label>
            <input type="text" name="username" class="form-control" value={{$post->username}}>
        </div>

        <div class="mb-3">
            <label> <b>Password</b></label>
            <input type="Password" name="pass" class="form-control" value={{$post->pass}}>
        </div>

         <input type="submit" name="insert" value="INSERT" class="btn btn-success">

    </form>

    </div>
</body>
</html> 
