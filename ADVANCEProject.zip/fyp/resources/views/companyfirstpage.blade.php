<!DOCTYPE html>
<html>
    <head> 
        <title></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    
<body>
<div class="container">
<<h1 class="text-center">Orders</h1> <br>
	<table class="table table-bordered shadow text-center table-striped">
		<tr>
			<th>Item name</th>
			<th>Full name</th>
			<th>Address </th>
            <th>Phone No</th>
			<th>E-mail </th>
           
		</tr>
		@foreach($post as $post)
		<tr>
			<td>{{$post->Item_nameadded}}</td>
			<td>{{$post->Full_name}}</td>
            <td>{{$post->address}}</td>
			<td>{{$post->phone_no}}</td>
            <td>{{$post->email}}</td>
		</tr>
		@endforeach
	</table>
	
</div>


    
</body>
</html> 
