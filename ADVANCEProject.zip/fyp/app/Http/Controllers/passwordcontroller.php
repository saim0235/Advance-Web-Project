<?php

namespace App\Http\Controllers;
use App\Models\passwordmodel;
use Illuminate\Http\Request;

class passwordcontroller extends Controller
{

    public function verifyme(Request $request)
    {   
        $name=passwordmodel::select('companyusername')->get();  
        $data = json_decode($name, true);
        $checkname = $data[0]['companyusername'];

        $name1=passwordmodel::select('companypassword')->get();  
        $data1 = json_decode($name1, true);
        $checkname1 = $data1[0]['companypassword'];



        $name2=passwordmodel::select('adminusername')->get();  
        $data2 = json_decode($name2, true);
        $checkname2 = $data2[0]['adminusername'];

        $name3=passwordmodel::select('adminpassword')->get();  
        $data3 = json_decode($name3, true);
        $checkname3 = $data3[0]['adminpassword'];

        // echo $checkname2;
        // echo $checkname3;
        $ab=$request->input('username');
        $ab1=$request->input('password');
        // echo $ab;
        if($checkname==$ab)
        {
            if($checkname1==$ab1)
            {
                return view('company');
            }
        }

        if($checkname2==$ab)
        {
            if($checkname3==$ab1)
            {
                return view('adminpanel');
            }
        }
            echo "FAILED TO LOGIN";
    
    }



    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
