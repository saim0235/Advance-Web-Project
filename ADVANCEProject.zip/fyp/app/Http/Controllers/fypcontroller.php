<?php

namespace App\Http\Controllers;

use App\Models\fyp;
use Illuminate\Http\Request;

class fypcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('company');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    // public function create()
    // {
    //     //
    // }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // $name = $request->file('pic')->getClientOriginalName();
 
        // $path = $request->file('pic')->store('public/images');
        $post=new fyp;
        $post->Item_catagory=$request->get('catagory');
        $post->Item_type=$request->get('type');
        $post->Item_name=$request->get('name');
        $post->Item_title=$request->get('title');
        $post->Item_descripion=$request->get('description');
        $post->Item_price=$request->get('price');
        $post->Item_quality=$request->get('quality');
        $post->Item_delivery_time=$request->get('time');


        // if($request->gex t('pic'))
        // {
        //     $file=$request->file('pic');
        //     $extention=$file->getClientOrigianlExtension();
        //     $filename=time().'.'.$extention;
        //     $file->move('uploads/students/',$filename);
        //     $post->Item_picture=$filename;
        // }
        $post->Item_picture=$request->get('pic');
        // $post->name = $name;
        $post->save();


        return redirect('show');
    }









    /**
     * 
     * 
     * 
     * 
     * 
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(fyp $id)
    {
        $post=fyp::all();
        return view('companyshow',['post'=>$post]);
    }

    public function homeshow(fyp $id)
    {
        $post=fyp::all();
        return view('Home',['post'=>$post]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(fyp $post,$id)
    {
        $post=fyp::find($id);
        return view('edit',['post'=>$post]);
    }

    public function edit1(fyp $post,$id)
    {
        $post=fyp::find($id);
        return view('form',['post'=>$post]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, fyp $post, $id)
    {
        $post=fyp::find($id);
        $post->Item_catagory=$request->get('catagory');
        $post->Item_type=$request->get('type');
        $post->Item_name=$request->get('name');
        $post->Item_title=$request->get('title');
        $post->Item_descripion=$request->get('description');
        $post->Item_price=$request->get('price');
        $post->Item_quality=$request->get('quality');
        $post->Item_delivery_time=$request->get('time');
        // $post->Item_picture=$request->get('picture');
        $post->save();


        return redirect('show');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(fyp $post,$id)
    {
        $post=fyp::find($id);
        $post->delete();
        return redirect('show');
    }
}
