<!DOCTYPE html>
<html>
    <head> 
        <title> Admin Panel</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    
<body>
<h1 class="text-center">builder list</h1> <br>
<div class="container">
	<table class="table table-bordered shadow text-center table-striped">
		<tr>
			<th>id</th>
			<th>Full Name</th>
			<th>Age </th>
            <th>Phone Number</th>
			<th>Expert </th>
            <th>Rates</th>
			<th>Username </th>
            <th>Password</th>
		</tr>
		<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($post->id); ?></td>
			<td><?php echo e($post->buildername); ?></td>
			<td><?php echo e($post->age); ?></td>
            <td><?php echo e($post->Phone_no); ?></td>
			<td><?php echo e($post->information); ?></td>
            <td><?php echo e($post->rates); ?></td>
			<td><?php echo e($post->username); ?></td>
            <td><?php echo e($post->pass); ?></td>
			<td><a href="/delete1/<?php echo e($post->id); ?>" class="btn btn-danger">delete</a></td>
			<td><a href="/edit1/<?php echo e($post->id); ?>" class="btn btn-success">edit</a></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>


	<!-- <form method="GET" action="/companyfirstpage">
<input type="submit" name="insert" Value="Check Any order"class="btn btn-success">
</form> -->
</br>
	
</div>


    
</body>
</html> 
<?php /**PATH C:\Xampp 8.1\htdocs\fyp\resources\views/buildershow.blade.php ENDPATH**/ ?>