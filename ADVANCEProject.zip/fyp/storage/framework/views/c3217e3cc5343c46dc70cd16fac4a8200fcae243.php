<!DOCTYPE html>
<html>
    <head> 
        <title>Form</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    
<body>
    <h1 class="text-center">User Information</h1> <br>
    <div class="container">

    <form method="GET" action="/store3">

        <div class="mb-3">
            <label> <b>Added Item Name</b></label>
            <input type="text" name="name" class="form-control" value=<?php echo e($post->Item_name); ?>>
        </div>

        <div class="mb-3">
            <label> <b>Full Name</b></label>
            <input type="text" name="full_name" class="form-control">
        </div>


        <div class="mb-3">
            <label> <b>Address</b></label>
            <input type="text" name="address" class="form-control">
        </div>

        <div class="mb-3">
            <label> <b> Phone Number</b></label>
            <input type="text" name="number" class="form-control" >
        </div>

        <div class="mb-3">
            <label> <b>E-Mail</b></label>
            <input type="text" name="mail" class="form-control" >
        </div>

            <input type="submit" name="submit" value="submit" class="btn btn-success">

    </form>

    </div>
</body>
</html> 
<?php /**PATH C:\Xampp 8.1\htdocs\fyp\resources\views/form.blade.php ENDPATH**/ ?>