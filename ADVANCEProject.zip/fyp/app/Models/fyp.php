<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class fyp extends Model
{
    use HasFactory;
    protected $table="company";
    protected $fillable =['Item_catagory','Item_type','Item_name','Item_title','Item_descripion','Item_price','Item_quality','Item_delivery_time','Item_picture'];
}
