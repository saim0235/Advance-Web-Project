<!DOCTYPE html>
<html>
    <head> 
        <title> Home Items</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    
<body>
<div class="container">
    <<h1 class="text-center">HOME</h1> <br>
	<table class="table table-bordered shadow text-center table-striped">
		<tr>
			<!-- <th>id</th> -->
			<th>Catagory</th>
			<th>type </th>
            <th>name</th>
			<th>title </th>
            <th>description</th>
			<th>price </th>
            <th>Quality</th>
			<th>Delivery Time</th>
            <th>Image Of project</th>
			<th>Cart</th>
		</tr>
		<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<!-- <td><?php echo e($post->id); ?></td> -->
			<td><?php echo e($post->Item_catagory); ?></td>
			<td><?php echo e($post->Item_type); ?></td>
            <td><?php echo e($post->Item_name); ?></td>
			<td><?php echo e($post->Item_title); ?></td>
            <td><?php echo e($post->Item_descripion); ?></td>
			<td><?php echo e($post->Item_price); ?></td>
            <td><?php echo e($post->Item_quality); ?></td>
			<td><?php echo e($post->Item_delivery_time); ?></td>
            <!-- <td><?php echo e($post->Item_picture); ?></td> -->
			<td><img src="<?php echo e(asset($post->Item_picture)); ?>" > </td>
			<td><a href="/form/<?php echo e($post->id); ?>" class="btn btn-success">Add To Cart</a></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>


	<form method="GET" action="/1">
		<input type="submit" name="" value="SigIn" class="btn btn-success">
	</form>

    <br>


    <form action="/builderprofilecheck">
        <input type="submit" name="submit" value="Builder Profile" class="btn btn-success">
    </form>
</div>
    
</body>
</html> 
<?php /**PATH C:\Xampp 8.1\htdocs\fyp\resources\views/Home.blade.php ENDPATH**/ ?>