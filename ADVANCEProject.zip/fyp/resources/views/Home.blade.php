<!DOCTYPE html>
<html>
    <head> 
        <title> Home Items</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    
<body>
<div class="container">
    <<h1 class="text-center">HOME</h1> <br>
	<table class="table table-bordered shadow text-center table-striped">
		<tr>
			<!-- <th>id</th> -->
			<th>Catagory</th>
			<th>type </th>
            <th>name</th>
			<th>title </th>
            <th>description</th>
			<th>price </th>
            <th>Quality</th>
			<th>Delivery Time</th>
            <th>Image Of project</th>
			<th>Cart</th>
		</tr>
		@foreach($post as $post)
		<tr>
			<!-- <td>{{$post->id}}</td> -->
			<td>{{$post->Item_catagory}}</td>
			<td>{{$post->Item_type}}</td>
            <td>{{$post->Item_name}}</td>
			<td>{{$post->Item_title}}</td>
            <td>{{$post->Item_descripion}}</td>
			<td>{{$post->Item_price}}</td>
            <td>{{$post->Item_quality}}</td>
			<td>{{$post->Item_delivery_time}}</td>
            <!-- <td>{{$post->Item_picture}}</td> -->
			<td><img src="{{asset($post->Item_picture)}}" > </td>
			<td><a href="/form/{{$post->id}}" class="btn btn-success">Add To Cart</a></td>
		</tr>
		@endforeach
	</table>


	<form method="GET" action="/1">
		<input type="submit" name="" value="SigIn" class="btn btn-success">
	</form>

    <br>


    <form action="/builderprofilecheck">
        <input type="submit" name="submit" value="Builder Profile" class="btn btn-success">
    </form>
</div>
    
</body>
</html> 
