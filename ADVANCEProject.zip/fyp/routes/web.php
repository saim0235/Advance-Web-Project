<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\fypcontroller;
use App\Http\Controllers\user;
use App\Http\Controllers\buildercontroller;
use App\Http\Controllers\passwordcontroller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('company');
// });

Route::get('/10', function () {
    return view('addbuilder');
});

Route::get('/check', function () {
    return view('builderprofilecheck');
});

// Route::get('/', function () {
//     return view('adminpanel');
// });

Route::get('/20', function () {
    return view('builderlogin');
});

Route::get('/2', function () {
    return view('login');
});

Route::get('/1', function () {
    return view('Loginshow');
});

Route::get('/', function () {
    return redirect('Home');
});


Route::get('check',[passwordcontroller::class,'verifyme']);

Route::get('verify',[buildercontroller::class,'verifyme']);
Route::get('builderprofilecheck',[buildercontroller::class,'show1']);
Route::get('store2',[buildercontroller::class,'store2']);
    Route::get('buildershow',[buildercontroller::class,'show']);
Route::get('delete1/{id}',[buildercontroller::class,'destroy']);
Route::get('edit1/{id}',[buildercontroller::class,'edit']);
Route::get('update1/{id}',[buildercontroller::class,'update']);

// Route::get('company',[fypcontroller::class,'view']);
Route::get('store',[fypcontroller::class,'store']);
Route::get('show',[fypcontroller::class,'show']);
Route::get('delete/{id}',[fypcontroller::class,'destroy']);
Route::get('edit/{id}',[fypcontroller::class,'edit']);
Route::get('update/{id}',[fypcontroller::class,'update']);
Route::get('Home',[fypcontroller::class,'homeshow']);
Route::get('form/{id}',[fypcontroller::class,'edit1']);

Route::get('store3',[user::class,'store']);
Route::get('companyfirstpage',[user::class,'show1']);

