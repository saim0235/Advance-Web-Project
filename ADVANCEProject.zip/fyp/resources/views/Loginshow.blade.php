<!DOCTYPE html>
<html>
    <head> 
        <title> Builder</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    
<body>

    <h1 class="text-center">Login</h1> <br>
    <div class="container">
    <table class="table table-bordered shadow text-center table-striped">

    <tr>
    <th>
    <form method="GET" action="/20">
        <div class="mb-3">
            <label> <b>Press Heree Builder Login</b></label>
            <input type="submit" name="p" value="Press" class="btn btn-success">
        <div>
    </div>
    <br>
</th>

<br>
</th>
</tr>
</table>
</div>




    <div class="container">
    <table class="table table-bordered shadow text-center table-striped">

<th>
    <form method="GET" action="/2">
        <div class="mb-3">
            <label> <b>Press Here Company Login</b></label>
            <input type="submit" name="Press" value="Press" class="btn btn-success">
        <div>
    </div>
    <br>

</th>

<th>

    <form method="GET" action="/2">
        <div class="mb-3">
            <label> <b>Press Here Admin Login</b></label>
            <input type="submit" name="Press" value="Press" class="btn btn-success">
        <div>
    </div>
<br>
</th>
</tr>
</table>
</body>
</html> 
