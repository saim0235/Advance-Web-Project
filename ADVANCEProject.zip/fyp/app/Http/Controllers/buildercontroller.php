<?php

namespace App\Http\Controllers;
use App\Models\builder;
use Illuminate\Http\Request;

class buildercontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    // public function create()
    // {
    //     //
    // }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store2(Request $request)
    {
        $post=new builder;
        $post->buildername=$request->get('buildername');
        $post->age=$request->get('age');
        $post->Phone_no=$request->get('Phone_no');
        $post->information=$request->get('information');
        $post->rates=$request->get('rates');
        $post->username=$request->get('username');
        $post->pass=$request->get('pass');
        $post->save();


        return redirect('buildershow');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(builder $id)
    {
        $post=builder::all();
        return view('buildershow',['post'=>$post]);
    }


    public function show1(builder $id)
    {
        $post=builder::all();
        return view('builderprofilecheck',['post'=>$post]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(builder $post,$id)
    {
        $post=builder::find($id);
        return view('builderedit',['post'=>$post]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,builder $post, $id)
    {
        $post=builder::find($id);
        $post->buildername=$request->get('buildername');
        $post->age=$request->get('age');
        $post->Phone_no=$request->get('Phone_no');
        $post->information=$request->get('information');
        $post->rates=$request->get('rates');
        $post->username=$request->get('username');
        $post->pass=$request->get('pass');
   
        $post->save();


        return redirect('buildershow');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(builder $post,$id)
    {
        $post=builder::find($id);
        $post->delete();
        return redirect('buildershow');
    }

    public function verifyme(Request $request)
    {   
        $name=builder::select('username')->get();  
        $data = json_decode($name, true);
        $checkname = $data[0]['username'];

        $name1=builder::select('pass')->get();  
        $data1 = json_decode($name1, true);
        $checkname1 = $data1[0]['pass'];

        // echo $checkname;
        // echo $checkname1;
        $ab=$request->input('username');
        $ab1=$request->input('password');
        // echo $ab;
        if($checkname==$ab)
        {
            if($checkname1==$ab1)
            {
                return redirect('builderprofilecheck');
            }
        }
            echo "FAILED TO LOGIN";
    
    }
}
