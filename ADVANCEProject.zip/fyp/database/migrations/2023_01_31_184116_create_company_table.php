<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('company', function (Blueprint $table) {
            $table->id();
            $table->string('Item_catagory');
            $table->string('Item_type');
            $table->string('Item_name');
            $table->string('Item_title');
            $table->longtext('Item_descripion');
            $table->string('Item_price');
            $table->string('Item_quality');
            $table->string('Item_delivery_time');
            $table->text('Item_picture');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('company');
    }
};
