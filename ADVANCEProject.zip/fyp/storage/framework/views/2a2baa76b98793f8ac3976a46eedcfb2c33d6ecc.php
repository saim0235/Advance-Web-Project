<!DOCTYPE html>
<html>
    <head> 
        <title> Company</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    
<body>

    <h1 class="text-center">UPDATE</h1> <br>
    <div class="container">

    <form method="GET" action="/update/<?php echo e($post->id); ?>">
        
        <div class="mb-3">
            <label><b>Item Catagory </b></label>
            <select name="catagory" id="catagory" class="mb-3" >
                <option >Interior Paint</option>
                <option >Exterior Paint</option>
                <option >Interior Tile</option>
                <option >Exterior Tile</option>
                <option >Interior Marble</option>
                <option >Exterior Marble</option>
                <option >Sanitary Showers</option>
                <option v>Bath Tub</option>
                <option >Sanitary Showers</option>
                <option >Water Closet</option>
                <option >Cement</option>
                <option >Bricks</option>
            </select>
        </div>


        <div class="mb-3">
            <label> <b>type</b></label>
            <input type="text" name="type" class="form-control" value=<?php echo e($post->Item_type); ?>>
        </div>


        <div class="mb-3">
            <label> <b>Name</b></label>
            <input type="text" name="name" class="form-control" value=<?php echo e($post->Item_name); ?>>
        </div>

        <div class="mb-3">
            <label> <b>Quality</b></label>
            <input type="text" name="quality" class="form-control" value=<?php echo e($post->Item_quality); ?> >
        </div>

        <div class="mb-3">
            <label> <b>Title</b></label>
            <input type="text" name="title" class="form-control" value=<?php echo e($post->Item_title); ?> >
        </div>

        <div class="mb-50">
            <label > <b>Description</b></label>
            <input type="text" name="description" class="form-control" value=<?php echo e($post->Item_descripion); ?>>
        </div>

        <div class="mb-3">
            <label> <b>Price</b></label>
            <input type="text" name="price" class="form-control" value=<?php echo e($post->Item_price); ?> >
        </div>

        <div class="mb-3">
            <label> <b>Delivery Time</b></label>
            <input type="text" name="time" class="form-control" value=<?php echo e($post->Item_delivery_time); ?> >
        </div>

        <div class="mb-3">
            <label> <b>Upload Picture</b></label>
            <input type="file" name="picture" class="form-control" value=<?php echo e($post->Item_picture); ?>>
        </div>

            <input type="submit" name="update" value="UPDATE" class="btn btn-success">

    </form>

    </div>
</body>
</html> 
<?php /**PATH C:\Xampp 8.1\htdocs\fyp\resources\views/edit.blade.php ENDPATH**/ ?>